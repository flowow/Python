import pandas_datareader.data as web
import pandas as pd
import numpy as np
import datetime as dt
import matplotlib.pyplot as plt

start = dt.datetime(2007, 1, 1)
end = dt.date.today()
s = web.YahooDailyReader('000660.KS', start, end, adjust_price=True).read()
s['Rtn'] = np.log(s['Close']) - np.log(s['Close'].shift(1))
s['MRtn'] = s['Rtn'].rolling(window=120).mean() * 252
s['MVol'] = s['Rtn'].rolling(window=120).std() * np.sqrt(252)
s = s.dropna()

plt.figure(figsize=(20,6))
plt.plot(s['MRtn'], color='red', linewidth=1)
plt.axhline(y=0)
plt.title("Moving Return Chart")
plt.show()

plt.figure(figsize=(20,6))
plt.plot(s['MVol'], color='blue', linewidth=1)
plt.title("Moving Volatility Chart")
plt.show()

# 이 주가와 동일한 평균과 표준편차를 갖는 정규분포를 생성한다
mu = s['Rtn'].mean()
std = s['Rtn'].std()
nordist = np.random.normal(mu, std, len(s))
plt.figure(figsize=(10,10))
_, _, _ = plt.hist(s['Rtn'], bins=100, alpha=0.6)
_, _, _ = plt.hist(nordist, bins=100, alpha=0.6)
plt.show()

plt.figure(figsize=(15,10))
plt.scatter(s['MVol'], s['MRtn'])







